package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Main3Activity extends AppCompatActivity {

    ListView listView;
    ArrayList<Fooditem> arrayList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);


        listView = (ListView) findViewById(R.id.listview);
        Fooditem p1 = new Fooditem("Chicken Handi","700");
        Fooditem p2 = new Fooditem("Sada Naan","20");
        Fooditem p3 = new Fooditem("Haleem","400");
        Fooditem p4 = new Fooditem("Drink","50");

        arrayList.add(p1);
        arrayList.add(p2);
        arrayList.add(p3);
        arrayList.add(p4);

        myArrayAdapter arrayAdapter = new myArrayAdapter(this,R.layout.adaptor_view_layout,arrayList);
        listView.setAdapter(arrayAdapter);
    }
}
