package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class signup extends AppCompatActivity {
    EditText signup_email;
    EditText signup_pass;
    DatabaseReference reff;
    Member member;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        member = new Member();
        signup_email = (EditText) findViewById(R.id.Email);
        signup_pass = (EditText) findViewById(R.id.Password);
        reff = FirebaseDatabase.getInstance().getReference("Member");
    }

    public void do_sign_up(View view){
        String email = signup_email.getText().toString();
        String pass = signup_pass.getText().toString();

        if (!TextUtils.isEmpty(email)) {

            String id = reff.push().getKey();
            member.setEmail(email);
            member.setpass(pass);

            reff.child(id).setValue(member);
            Toast.makeText(signup.this, "signed up", Toast.LENGTH_LONG).show();

        }
    }
}
