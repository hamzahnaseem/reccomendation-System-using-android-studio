package com.example.project;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class myArrayAdapter extends ArrayAdapter<Fooditem> {

    public static final String TAG = "myArrayAdaptor";
    private Context mContext;
    int mResource;
    ArrayList<Fooditem> arrayList;

    public myArrayAdapter(@NonNull Context context, int resource, @NonNull ArrayList<Fooditem> objects) {
        super(context, resource, objects);
        this.mContext = context;
        mResource = resource;
        this.arrayList = objects;
    }

    public ArrayList<Fooditem> getArrayList() {
        return arrayList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        String Name = getItem(position).getName();
        String price = getItem(position).getPrice();

        LayoutInflater infaltor = LayoutInflater.from(mContext);
        convertView = infaltor.inflate(mResource, parent, false);

        TextView t1 = (TextView) convertView.findViewById(R.id.textView);
        TextView t2 = (TextView) convertView.findViewById(R.id.textView1);
        t1.setText(Name);
        t2.setText(price);

        return convertView;

    }

    public void update(ArrayList<Fooditem> p)
    {
        arrayList = new ArrayList<>();
        arrayList.addAll(p);
        notifyDataSetChanged();

    }
}
