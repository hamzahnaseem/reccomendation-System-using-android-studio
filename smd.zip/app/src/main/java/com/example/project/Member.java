package com.example.project;

public class Member {

    private String email;
    private String pass;

    public Member(){}

    public String getEmail(){
        return email;
    }
    public String getPass(){
        return pass;
    }
    public void setEmail(String e){
        email = e;
    }
    public void setpass(String p){
        pass = p;
    }
}
