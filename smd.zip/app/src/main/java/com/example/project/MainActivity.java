package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class MainActivity extends AppCompatActivity {
//    Textview signin;
    IncomingSms sms = new IncomingSms();
    private AdView mAdView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
//        signin = (Textview) findViewById(R.id.signin);

    }

    @Override
    protected void onStart(){
        super.onStart();
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(sms,filter);
    }
    protected void onStop(){
        super.onStop();
        unregisterReceiver(sms);
    }



    public void signin(View view){
        Intent intent = new Intent(this,signin.class);
        startActivity(intent);
        Toast.makeText(MainActivity.this, "sign in" , Toast.LENGTH_LONG).show();
    }

    public void signup(View view){
        Intent intent = new Intent(this,signup.class);
        startActivity(intent);
        Toast.makeText(MainActivity.this, "sign up" , Toast.LENGTH_LONG).show();
    }

}
