package com.example.project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class signin extends AppCompatActivity {
    EditText signin_email;
    EditText signin_pass;
    DatabaseReference reff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);

        signin_email = (EditText) findViewById(R.id.Email);
        signin_pass = (EditText) findViewById(R.id.Password);

    }

    public void RedirectToSignUpPage(View view){
        Intent intent = new Intent(this,signup.class);
        startActivity(intent);
        Toast.makeText(signin.this, "sign up" , Toast.LENGTH_LONG).show();
    }

    public void check_sign_in_credentials(View view){
        reff = FirebaseDatabase.getInstance().getReference("Member");
        final Intent intent = new Intent(this, Main2Activity.class);

        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String email;
                String pass;
                int a=0;

                for (DataSnapshot member_snap : dataSnapshot.getChildren()){
                    Member member = member_snap.getValue(Member.class);
                    email = signin_email.getText().toString();
                    pass = signin_pass.getText().toString();

                    if (email.equals(member.getEmail()) && pass.equals(member.getPass()))
                    {
                        a=1;
                        Toast.makeText(signin.this, "success" , Toast.LENGTH_LONG).show();
                        break;
                    }

                }
                if (a==0)
                Toast.makeText(signin.this, "sign in failed" , Toast.LENGTH_LONG).show();
                if (a==1) {

                    startActivity(intent);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
