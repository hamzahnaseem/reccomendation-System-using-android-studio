package com.example.project;

public class Fooditem {


    String name;
    String price;

    public Fooditem(String name, String p) {
        this.name = name;
        this.price = p;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(String
                                 price) {
        this.price = price;
    }

    public String getPrice() {
        return price;
    }
}
